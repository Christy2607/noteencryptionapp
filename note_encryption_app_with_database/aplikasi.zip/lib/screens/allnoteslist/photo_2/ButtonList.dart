// import 'package:flutter/material.dart';
// import 'package:flutter/src/widgets/container.dart';
// import 'package:flutter/src/widgets/framework.dart';
// import 'package:note_encryption_app_with_database/databaseHandler/DbHelper.dart';

// class ClickButtonDelete extends StatelessWidget {
//   final db = DbHelper();
//   final Function deleteFunction;

//   ClickButtonDelete({
//     required this.deleteFunction,
//     Key? key,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return FutureBuilder(
//       future: db.getPhotos(),
//       initialData: const [],
//       builder: (BuildContext context, AsyncSnapshot<List> snapshot) {
//         var data = snapshot.data;
//         var dataLength = data!.length;

//         return 
//       },
//     );
//   }
// }
